package org.scratchgame.service;

public class ConfigValidationServiceImpl {
}
