package org.scratchgame.service;

public interface ConfigValidationService {
  
}
